import React from "react";
import { Link } from "react-router-dom";
import { FaTachometerAlt, FaBook, FaCalendar, FaEnvelope, FaQuestion } from "react-icons/fa";

function Sidebar() {
  const menuItems = [
    { icon: <FaTachometerAlt />, label: "Dashboard", path: "/" },
    { icon: <FaBook />, label: "Courses", path: "/" },
    { icon: <FaCalendar />, label: "Calendar", path: "/" },
    { icon: <FaEnvelope />, label: "Inbox", path: "/" },
    { icon: <FaQuestion />, label: "Help", path: "/" }
  ];

  return (
    <div className="bg-blue-800 text-white w-16 lg:w-60 p-4 space-y-6 sticky top-0 h-screen">
      {menuItems.map((item, index) => (
        <Link
          to={item.path}
          key={index}
          className="flex items-center gap-3 p-2 hover:bg-blue-600 rounded-lg transition-all"
        >
          <span className="text-xl">{item.icon}</span>
          <span className="hidden lg:inline">{item.label}</span>
        </Link>
      ))}
    </div>
  );
}

export default Sidebar;