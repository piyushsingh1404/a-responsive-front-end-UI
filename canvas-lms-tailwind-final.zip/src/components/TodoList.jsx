import React, { useState } from "react";

function TodoList({ todos }) {
  const [checkedItems, setCheckedItems] = useState({});

  const toggleCheck = (index) => {
    setCheckedItems((prev) => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  return (
    <ul className="space-y-3">
      {todos.map((todo, index) => (
        <li key={index} className="bg-white p-4 rounded shadow flex justify-between items-center">
          <div>
            <p className={checkedItems[index] ? "line-through text-gray-400" : ""}>
              {todo.task}
            </p>
            <span className="text-sm text-gray-500">Due: {todo.dueDate}</span>
          </div>
          <input
            type="checkbox"
            checked={checkedItems[index] || false}
            onChange={() => toggleCheck(index)}
            className="w-5 h-5"
          />
        </li>
      ))}
    </ul>
  );
}

export default TodoList;