import React from "react";
import { Link } from "react-router-dom";

function CourseCard({ course }) {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold">{course.title}</h3>
      <p className="text-gray-600 text-sm">Instructor: {course.instructor}</p>
      <div className="my-2 bg-gray-200 rounded-full h-2 overflow-hidden">
        <div
          className="bg-green-500 h-full"
          style={{ width: `${course.progress}%` }}
        ></div>
      </div>
      <Link to={`/courses/${course.id}`}>
        <button className="mt-2 bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700">
          Go to Course
        </button>
      </Link>
    </div>
  );
}

export default CourseCard;