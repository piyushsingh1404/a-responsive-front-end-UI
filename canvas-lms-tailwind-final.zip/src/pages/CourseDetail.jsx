import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";

const CourseDetail = () => {
  const { id } = useParams();
  const [tab, setTab] = useState("overview");

  const renderContent = () => {
    switch (tab) {
      case "overview":
        return (
          <div>
            <h3 className="text-lg font-bold mb-2">Course Overview</h3>
            <p>This course covers all essential concepts required for mastering the subject. You'll find resources, reading materials, and instructor notes here.</p>
          </div>
        );
      case "assignments":
        return (
          <div>
            <h3 className="text-lg font-bold mb-2">Assignments</h3>
            <ul className="list-disc ml-5 space-y-1">
              <li>Assignment 1 - Due: 2025-08-01</li>
              <li>Assignment 2 - Due: 2025-08-10</li>
              <li>Project Submission - Due: 2025-08-15</li>
            </ul>
          </div>
        );
      case "grades":
        return (
          <div>
            <h3 className="text-lg font-bold mb-2">Grades</h3>
            <table className="w-full table-auto border-collapse">
              <thead>
                <tr className="bg-gray-200">
                  <th className="border px-4 py-2">Assignment</th>
                  <th className="border px-4 py-2">Score</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border px-4 py-2">Assignment 1</td>
                  <td className="border px-4 py-2">85%</td>
                </tr>
                <tr>
                  <td className="border px-4 py-2">Assignment 2</td>
                  <td className="border px-4 py-2">90%</td>
                </tr>
                <tr>
                  <td className="border px-4 py-2">Project</td>
                  <td className="border px-4 py-2">92%</td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="p-6">
      <nav className="text-sm text-blue-600 mb-4">
        <Link to="/" className="hover:underline">Dashboard</Link> &gt; Course #{id} &gt; Module
      </nav>

      <h2 className="text-2xl font-bold mb-4">Course #{id} Details</h2>

      <div className="flex space-x-4 mb-6">
        <button onClick={() => setTab("overview")} className={tab === "overview" ? "font-bold text-blue-700" : "text-gray-600"}>Overview</button>
        <button onClick={() => setTab("assignments")} className={tab === "assignments" ? "font-bold text-blue-700" : "text-gray-600"}>Assignments</button>
        <button onClick={() => setTab("grades")} className={tab === "grades" ? "font-bold text-blue-700" : "text-gray-600"}>Grades</button>
      </div>

      <div className="bg-white p-4 rounded shadow">
        {renderContent()}
      </div>
    </div>
  );
};

export default CourseDetail;