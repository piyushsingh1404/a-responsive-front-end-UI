import React from "react";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";
import CourseCard from "../components/CourseCard";
import TodoList from "../components/TodoList";
import courses from "../data/courses.json";
import todos from "../data/todos.json";

function Dashboard() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 p-4 md:p-8 bg-gray-100">
        <Header studentName="Piyush" />
        <h2 className="text-xl font-semibold mb-4">Your Courses</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {courses.map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
        <h2 className="text-xl font-semibold mb-4">To-Do List</h2>
        <TodoList todos={todos} />
      </div>
    </div>
  );
}

export default Dashboard;